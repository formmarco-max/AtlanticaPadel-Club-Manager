# Dicionário de Dados
